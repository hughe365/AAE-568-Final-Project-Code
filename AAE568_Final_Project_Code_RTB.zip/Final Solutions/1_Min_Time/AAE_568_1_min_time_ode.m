%% Optimal Detumbling Strategies of a Rigid Spacecraft
%% Optimization: Minimum-Time
%% Solution Method: ODE

% Purdue University, AAE 568
% Ryan Giesen, Trevor Hanzel, Brandon Hughes

%% Setup
clc;
clear;

% Given
Ic = [1 0.5 -1; %[kg*m^2] inertia tensor
      0.5 2 1;
      -1 1 5];
Ic_inv = inv(Ic); % Compute inertia tensor inverse once for easier computation
w0 =  [1; 0.5; -1]; % [rad/s] Initial angular velocity 
umax = 0.5; %[N*m] Max Torque
h0 = norm(Ic*w0); % [kg*m^2/s] Initial angular momentum 

%Estimate Time
tf_guess = norm(Ic*w0)/umax;
tspan = [0 tf_guess];   %Simulate Longer

%% Solve
%Integrate Dynamics
[t, w] = ode45(@(t,w) detumble_ode(t, w, Ic, Ic_inv, umax), tspan, w0);


%% Calculations
%Torque and Angular Momentum
u_hist = zeros(length(t),3);
u_norm = [];
h = zeros(length(t),1);
for i = 1:length(t)%
    u_hist(i,:) = control_law(w(i,:)', Ic, umax)';
    u_norm(i) = norm(u_hist(i,:));
    h(i) = norm(Ic * w(i,:)');
end

%Print Estimated Time
t_sol = t;
tf = t(end);
fprintf('Estimated Detumble Time: %0.4f\n', tf)

% Calculate Fuel & Energy Cost
n = length(u_norm);
J_fuel = tf*sum(u_norm)/n;
J_energy = (0.5)*(u_norm*u_norm')*tf/n;
fprintf('Fuel Cost: %0.4f\n', J_fuel)
fprintf('Energy Cost: %0.4f\n', J_energy)

% Extend Plotting Window to Show Stability
t_stable = [];
t_extend = 5;
for i = 0:t_extend
    t_stable_i = tf + i;
    t_stable = [t_stable;t_stable_i];
    w = [w;w(end,:)];
    u_hist = [u_hist;u_hist(end,:)];
    h = [h;h(end)];
end
t = [t;t_stable];

%% Plots
%Plot Angular Velocity
figure(1);
clf
subplot(1,3,1)
plot(t, w, 'LineWidth', 2);
xlabel('Time (s)');
ylabel('\omega (rad/s)');
legend('\omega_x','\omega_y','\omega_z');
title('Angular Velocity, Min-Time ODE');
grid on
xlim([min(t) max(t)])
ylim_vals = ylim;
ylim([ylim_vals(1)*1.1 ylim_vals(2)*1.1])
whitePlot(gcf,gca);

%Plot Torque
subplot(1,3,2)
plot(t, u_hist, 'LineWidth', 2);
xlabel('Time (s)');
ylabel('\tau (Nm)');
legend('u_x','u_y','u_z');
title('Control Torque, Min-Time ODE');
grid on
xlim([min(t) max(t)])
ylim_vals = ylim;
ylim([ylim_vals(1)*1.1 ylim_vals(2)*1.1])
whitePlot(gcf,gca);

% Plot Angular Momentum
subplot(1,3,3)
plot(t, h, 'LineWidth', 2);
xlabel('Time (s)');
ylabel('||H|| (kgm^2/s)');
legend('||H||')
title('Angular Momentum Magnitude, Min-Time ODE');
xlim([min(t) max(t)])
ylim_vals = ylim;
ylim([ylim_vals(1)*1.1 ylim_vals(2)*1.1])
grid on;
whitePlot(gcf,gca);

% Plot Control Saturation
figure(10)
hold on
plot(t_sol,u_norm,'LineWidth',2);
hold off
grid on

%% Functions
function wdot = detumble_ode(~, w, Ic, Ic_inv, umax)

    %Control Input
    u = control_law(w, Ic, umax);

    %Euler Rotational Dynamics
    wdot = Ic_inv * (u - cross(w, Ic*w));

end

function u = control_law(w, Ic, umax)

    %Angular Momentum
    H = Ic * w;
    
    %Turn Off Torque
    if norm(w) > 1e-5
        u = -umax * H / norm(H);
    else
        u = [0;0;0];
    end

end