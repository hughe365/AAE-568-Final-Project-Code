%% Optimal Detumbling Strategies of a Rigid Spacecraft
%% Optimization: Minimum-Time Spin-Stabilized
%% Solution Method: BVP4C

% Purdue University, AAE 568
% Ryan Giesen, Trevor Hanzel, Brandon Hughes

% Finding Optimal Minimum Time Control for Rigid Body De-Spin by making use of 
% the bvp4c solver to solve the TPBVP for the optimal control problem.

%% Setup
clear; clc; 

% Given
Ic = [1 0.5 -1;
      0.5 2 1;
      -1 1 5]; % [kg*m^2] inertia tensor

tau_max = 0.5; % [N*m] torque constraint
omega0 = [1; 0.5; -1]; % [rad/s] Initial angular velocity
tf_guess = 10; % Initial guess for final time

%% Solve
options = bvpset('Stats','on','RelTol',1e-4,'NMax',5000);
solinit = bvpinit(linspace(0,1,50), @(s) guess(s, omega0), tf_guess);
sol = bvp4c(@(s,y,tf) BVP_ode(s,y,tf,Ic,tau_max), ...
            @(ya,yb,tf) BVP_bc(ya,yb,tf,omega0,Ic,tau_max), ...
            solinit,options);

% Extract solution
s = sol.x;
y = sol.y;
tf = sol.parameters;
t = s * tf; % Scale time by the final time

%% Calculations
% Control inputs
tau_star_norm = [];
tau = zeros(3,length(t));
for i = 1:length(t)
    lambda_i = y(4:6,i);
    tau_star_i = -(Ic \ lambda_i);
 
    % Limit tau_star_i to tau_max
    if norm(tau_star_i) > tau_max
        tau_star_i = tau_max * (tau_star_i / norm(tau_star_i));
        tau_star_norm_i = norm(tau_star_i);
        tau_star_norm = [tau_star_norm;tau_star_norm_i];
    end
    
    tau(:,i) = tau_star_i;
end

t_fuel = t(end);

% Calculate Fuel & Energy Cost
n = length(tau_star_norm);
J_fuel = t_fuel*sum(tau_star_norm)/n;
J_energy = (0.5)*(tau_star_norm'*tau_star_norm)*tf/n;
fprintf('Fuel Cost: %0.4f\n', J_fuel)
fprintf('Energy Cost: %0.4f\n',J_energy)

% Calculate Angular Momentum
h = (Ic * y(1:3,:))';
h_mag = vecnorm(h, 2, 2);

% Extend plotting Window to Show Stabilization
tf = t(end);
t_stable = [];
t_extend = 5;
for i = 0:t_extend
    t_stable_i = tf + i;
    t_stable = [t_stable t_stable_i];
    y = [y y(:,end)];
    tau = [tau zeros(3,1)];
    h_mag = [h_mag;h_mag(end)];
end
t = [t t_stable];


%% Plots
% Angular velocities
w1 = y(1,:);
w2 = y(2,:);
w3 = y(3,:);
figure(2);
clf
subplot(1,3,1);
hold on; grid on;
plot(t,w1,'LineWidth',2);
plot(t,w2,'LineWidth',2);
plot(t,w3,'LineWidth',2);
xlabel('Time (s)');
ylabel('\omega (rad/s)');
title('Angular Velocity, Min-Time TPBVP','Color','k');
legend('\omega_x','\omega_y','\omega_z', 'Location', 'Best');
xlim([min(t) max(t)])
ylim_vals = ylim;
ylim([ylim_vals(1)*1.1 ylim_vals(2)*1.1])
box on
whitePlot(gcf,gca);

% Torque
subplot(1,3,2);
hold on; grid on;
plot(t,tau(1,:),'LineWidth',2);
plot(t,tau(2,:),'LineWidth',2);
plot(t,tau(3,:),'LineWidth',2);
xlabel('Time (s)');
ylabel('\tau (Nm)');
title('Control Torque, Min-Time TPBVP','Color','k');
legend('\tau_x','\tau_y','\tau_z', 'Location', 'Best');
xlim([min(t) max(t)])
ylim_vals = ylim;
ylim([ylim_vals(1)*1.1 ylim_vals(2)*1.1])
box on
whitePlot(gcf,gca);

% Angular Momentum
h = (Ic * y(1:3,:))';
h_mag = vecnorm(h, 2, 2);
subplot(1,3,3);
hold on; grid on;
plot(t, h_mag, 'LineWidth', 2);
xlabel('Time (s)');
ylabel('||H|| (kgm^2/s)');
legend('||H||')
title('Angular Momentum Magnitude, Min-Time TPBVP');
xlim([min(t) max(t)])
ylim_vals = ylim;
ylim([ylim_vals(1)*1.1 ylim_vals(2)*1.1])
box on
grid on
whitePlot(gcf,gca);

%% Functions
function dyds = BVP_ode(~,y,tf,Ic,tau_max)
    omega = y(1:3);
    lambda = y(4:6);
    v = Ic \ lambda;

    % Optimal Control Law
    tau_star = -v;
    if norm(tau_star) > tau_max
        tau_star = tau_max * (tau_star / norm(tau_star));
    end

    % State dynamics
    omega_dot = Ic \ (tau_star - cross(omega, Ic*omega));

    % Costate dynamics
    term1 = cross(Ic*omega, v);
    term2 = Ic * cross(omega, v);

    lambda_dot = term1 - term2;

    dyds = tf * [omega_dot; lambda_dot];
end

function res = BVP_bc(ya,yb,~,omega0,Ic,tau_max)
    
    res1_3 = ya(1:3) - omega0; % Initial omega
    res4_6 = yb(1:3); % Final omega should be zero

    % Calculate Hamiltonian at final time
    lambda_f = yb(4:6);
    v_f = Ic \ lambda_f;
    tau_star_f = -v_f;
    if norm(tau_star_f) > tau_max
        tau_star_f = tau_max * (tau_star_f / norm(tau_star_f));
    end
    Hf = 1 + lambda_f' * (Ic \ (tau_star_f - cross(yb(1:3), Ic*yb(1:3)))); % Hamiltonian at final time

    res7 = Hf; % Hamiltonian should be zero at optimal solution

    res = [
        res1_3;
        res4_6;
        res7
    ];
end

% Initial Guess Function
function y0 = guess(s, omega0)

    omega = (1 - 0.2*s) * omega0;

    Ic = [1 0.5 -1;
          0.5 2 1;
          -1 1 5]; % kg*m^2
    lambda = 1e-1 * (Ic * omega0);
    y0 = [omega; lambda];
end
