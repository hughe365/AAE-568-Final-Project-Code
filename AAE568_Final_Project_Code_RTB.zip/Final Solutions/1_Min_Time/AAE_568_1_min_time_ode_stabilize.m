%% Optimal Detumling Strategies of a Rigid Spacecraft
%% Optimization: Minimum-Time Spin-Stabilized
%% Solution Method: ODE

% Purdue University, AAE 568
% Ryan Giesen, Trevor Hanzel, Brandon Hughes

%% Setup
clc;
clear;

%Given
I = [4 4 2]; % Assume axisymmetric spacecraft
Ic = diag(I); % [kg*m^2] inertia tensor
Ic_inv = inv(Ic); % Compute inertia tensor inverse
w0 =  [1; 0.5; -1]; % [rad/s] initial angular velocity
wf = [0; 
      0; 
      2]; % [rad/s] final angular velocity
umax = 0.5; %[N*m] Max Torque
h0 = norm(Ic*w0); % [kg*m^2/s] Initial angular momentum

%Estimate Time
tf_guess = norm(Ic*(w0-wf))/umax; % Initial guess for final time
tspan = [0 tf_guess];   %Simulate Longer

%Print Estimated Time
fprintf('Estimated Detumble Time: %0.4f\n', tf_guess)

%% Solve
%Integrate Dynamics
[t, w] = ode45(@(t,w) detumble_ode(t, w, wf, Ic, Ic_inv, umax), tspan, w0);

%% Calculations
%Torque and Angular Momentum
u_hist = zeros(length(t),3);
h = zeros(length(t),1);
for i = 1:length(t)
    u_hist(i,:) = control_law(w(i,:)',wf, Ic, umax)';
    u_norm(i) = norm(u_hist(i,:));
    h(i) = norm(Ic * w(i,:)');
end

t_sol = t;
tf = t(end);

% Calculate Fuel & Energy Cost
n = length(u_norm);
J_fuel = tf*sum(u_norm)/n;
J_energy = (0.5)*(u_norm*u_norm')*tf/n;
fprintf('Fuel Cost: %0.4f\n', J_fuel)
fprintf('Energy Cost: %0.4f\n', J_energy)

% Extend Plotting Window to Show Stability
t_stable = [];
t_extend = 5;
for i = 0:t_extend
    t_stable_i = tf + i;
    t_stable = [t_stable;t_stable_i];
    w = [w;w(end,:)];
    u_hist = [u_hist;u_hist(end,:)];
    h = [h;h(end)];
end
t = [t;t_stable];

%% Plots
%Plot Angular Velocity
figure(3);
clf
subplot(1,3,1)
plot(t, w, 'LineWidth', 2);
xlabel('Time (s)');
ylabel('\omega (rad/s)');
legend('\omega_x','\omega_y','\omega_z', 'Location', 'best');
title(["Angular Velocity, Min-Time","Spin-Stabilized ODE"]);
grid on
xlim([min(t) max(t)])
ylim_vals = ylim;
ylim([ylim_vals(1)*1.1 ylim_vals(2)*1.1])
whitePlot(gcf,gca);

%Plot Torque
subplot(1,3,2)
plot(t, u_hist, 'LineWidth', 2);
xlabel('Time (s)');
ylabel('\tau (Nm)');
legend('u_x','u_y','u_z', 'Location', 'best');
title(["Control Torque, Min-Time", "Spin-Stabilized ODE"]);
grid on
xlim([min(t) max(t)])
ylim_vals = ylim;
ylim([ylim_vals(1)*1.1 ylim_vals(2)*1.1])
whitePlot(gcf,gca);

% Plot Angular Momentum
subplot(1,3,3)
plot(t, h, 'LineWidth', 2);
xlabel('Time (s)');
ylabel('||H|| (kgm^2/s)');
legend('||H||');
title(["Angular Momentum Magnitude, Min-Time","Spin-Stabilized ODE"]);
grid on
xlim([min(t) max(t)])
ylim_vals = ylim;
ylim([ylim_vals(1)*1.1 ylim_vals(2)*1.1])
whitePlot(gcf,gca);

%% Functions
function wdot = detumble_ode(~, w, wf, Ic, Ic_inv, umax)

    %Control Input
    u = control_law(w, wf, Ic, umax);

    %Euler Rotational Dynamics
    wdot = Ic_inv * (u - cross(w, Ic*w));

end

function u = control_law(w, wf, Ic, umax)

    %Angular Momentum
    H = Ic * (w - wf);
    
    %Turn Off Torque
    if norm(w - wf) > 1e-5
        u = -umax * H / norm(H);
    else
        u = [0;0;0];
    end

end