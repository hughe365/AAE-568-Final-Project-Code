%% Optimal Detumbling Strategies of a Rigid Spacecraft
%% Optimization: Minimum-Energy
%% Solution Method: BVP4C

% Purdue University, AAE 568
% Ryan Giesen, Trevor Hanzel, Brandon Hughes

%% Setup
clear; clc; close all;

debug = false;

Given
Ic = [1 0.5 -1;
      0.5 2 1;
      -1 1 5]; % [kg*m^2] inertia tensor
tau_max = 0.5; % [N*m]

omega0 = [1; 0.5; -1]; % [rad/s] Initial angular velocity

%% Solve
% Solve known min time to start continuation
tf_1 = 11.93; % fixed time
endTime = 30.0; % end time for continuation

options = bvpset('Stats','on','RelTol',1e-9,'NMax',5000);
solInit = bvpinit(linspace(0,tf_1,500), guess(omega0));

odeFun = @(t,y) BVP_ode(t,y,Ic,tau_max);
bcFun = @(ya,yb) BVP_bc(ya,yb,omega0);
sol = bvp4c(odeFun, bcFun, solInit, options);

% Extract solution
t_min = sol.x;
y = sol.y;

% Save off control torque for plotting later
tau_minTime = zeros(3,length(t_min));
for i = 1:length(t_min)
    lambda_i = y(4:6,i);
    tau_star_i = -(Ic \ lambda_i);
    if norm(tau_star_i) > tau_max
        tau_star_i = tau_max * (tau_star_i / norm(tau_star_i));
    end

    tau_minTime(:,i) = tau_star_i;
end

plotResults(t_min,y,Ic,tau_max);

% Start continuation on final time
stepSize = 0.1;
tf_new = tf_1 + stepSize;
i = 0;
while tf_new <= endTime + 1e-12
      i = i+1;
      fprintf('Continuation step: tf_prev = %.2f -> tf_new = %.2f\n', tf_new - stepSize, tf_new);

      tf_prev = sol.x(end);
      guessFun = @(t) deval(sol, min(tf_prev, max(0, (tf_prev / tf_new) * t)));
      solInit = bvpinit(linspace(0,tf_new,50), guessFun);
      sol = bvp4c(odeFun, bcFun, solInit, options); 
      
      % Update for next iteration
      t = sol.x;
      y = sol.y;
      if debug
            plotResults(t,y,Ic,tau_max);
      end
      finalTime(i) = tf_new;
      totalEnergy(i) = 0.5 * trapz(t, sum((-(Ic \ y(4:6,:))).^2, 1)); % Calculate energy for current solution
      controlTorqueNorm(i) = max(vecnorm(-(Ic \ y(4:6,:)), 2, 1)); % Calculate max control torque magnitude for current solution
      tf_new = tf_new + stepSize;
end

plotResults(t,y,Ic,tau_max);

%% Calculations
% Calculate tau to use for energy calculation
tau_30 = zeros(3,length(t));
for i = 1:length(t)
    lambda_i = y(4:6,i);
    tau_star_i = -(Ic \ lambda_i);
    if norm(tau_star_i) > tau_max
        tau_star_i = tau_max * (tau_star_i / norm(tau_star_i));
    end

    tau_30(:,i) = tau_star_i;
end

% Calcualte control energy cost
energy = 0.5 * trapz(t, sum(tau_30.^2, 1)); % Integral of tau'*tau over time
disp(['Total Control Energy: ', num2str(energy)]);

%% Plots
% Plot torque magnitude vs time for min time and final solution
figure;
hold on; grid on;

t_extend = 5;
switchGap = 1e-3;
t_min_plot = [t_min, t_min(end) + switchGap, t_min(end) + switchGap + (1:t_extend)];
tau_min_plot = [vecnorm(tau_minTime, 2, 1), 0, zeros(1, t_extend)];

t_30_plot = [t, t(end) + switchGap, t(end) + switchGap + (1:t_extend)];
tau_30_plot = [vecnorm(tau_30, 2, 1), 0, zeros(1, t_extend)];

plot(t_min_plot, tau_min_plot, '-', 'LineWidth', 2, 'DisplayName', 't_f = Min Time');
plot(t_30_plot, tau_30_plot, '-', 'LineWidth', 2, 'DisplayName', 't_f = 30 s');
xlabel('Time (s)');
ylabel('Control Torque Magnitude (Nm)');
title('Control Torque Magnitude','Color','k');
legend('Location', 'best');
whitePlot(gcf,gca);

% Plot Energy and Control Torque vs Final Time on the same axes
figure;
ax = gca;
yyaxis left;
plot(finalTime, totalEnergy, 'b-', 'LineWidth', 2, 'DisplayName', 'Control Energy Cost');
ylabel('Energy Cost (J^2s)', 'Color', 'b');
ylim([0, 1.5]);
yticks(linspace(0, 1.5, 6));

yyaxis right;
plot(finalTime, controlTorqueNorm, 'k--', 'LineWidth', 2, 'DisplayName', 'Control Torque');
ylabel('Control Torque Magnitude (Nm)');
ylim([0, 1.5]);
yticks(linspace(0, 1.5, 6));

xlabel('Time (s)');
title('Control Energy Cost and Control Torque as a Function of Final Time','Color','k');
grid on;
legend('Location', 'best');
whitePlot(gcf,ax);
ax.YAxis(1).Color = 'b';
ax.YAxis(2).Color = 'k';

%% Functions
function plotResults(t, y, Ic, tau_max)
      % Plot results
      rows = 1;
      cols = 3;
      % Angular velocities
      w1 = y(1,:);
      w2 = y(2,:);
      w3 = y(3,:);

      % Control inputs
      tau = zeros(3,length(t));
      for i = 1:length(t)
          lambda_i = y(4:6,i);
          tau_star_i = -(Ic \ lambda_i);
          if norm(tau_star_i) > tau_max
              tau_star_i = tau_max * (tau_star_i / norm(tau_star_i));
          end

          tau(:,i) = tau_star_i;
      end

      % Angular Momentum
      h = (Ic * y(1:3,:))';
      h_mag = vecnorm(h, 2, 2);

      % Extend Plotting Window to Show Stability
      t_stable = [];
      t_extend = 5;
      tf = t(end);
      for i = 0:t_extend
          t_stable_i = tf + i;
          t_stable = [t_stable;t_stable_i];
          w1 = [w1, w1(end)];
          w2 = [w2, w2(end)];
          w3 = [w3, w3(end)];
          tau = [tau, zeros(3,1)];
          h_mag = [h_mag; h_mag(end)];
      end
      t = [t t_stable'];
      
      figure;
      subplot(rows,cols,1);
      hold on; grid on;
      plot(t,w1,'LineWidth',2);
      plot(t,w2,'LineWidth',2);
      plot(t,w3,'LineWidth',2);
      xlabel('Time (s)');
      ylabel('\omega (rad/s)');
      title({"Angular Velocity, Min-Energy"," TPBVP (t_f = 30 s)"},'Color','k');
      legend('\omega_x','\omega_y','\omega_z');
      whitePlot(gcf,gca);

      subplot(rows,cols,2);
      hold on; grid on;
      plot(t,tau(1,:),'LineWidth',2);
      plot(t,tau(2,:),'LineWidth',2);
      plot(t,tau(3,:),'LineWidth',2);
      xlabel('Time (s)');
      ylabel('\tau (Nm)');
      title({"Control Torque, Min-Energy","TPBVP (t_f = 30 s)"},'Color','k');
      legend('\tau_x','\tau_y','\tau_z');
      whitePlot(gcf,gca);

      % Angular Momentum
      subplot(rows,cols,3);
      hold on; grid on;
      plot(t, h_mag, 'LineWidth', 2);
      xlabel('Time (s)');
      ylabel('||H|| (kgm^2/s)');
      legend('||H||')
      title({"Angular Momentum Magnitude, Min-energy","TPBVP (t_f = 30 s)"},'Color','k');
      whitePlot(gcf,gca);

      % Plot norm of control input
      figure;
      hold on; grid on;
      plot(t, vecnorm(tau, 2, 1), 'k-', 'LineWidth', 2);
      xlabel('Time (s)');
      ylabel('Control Torque Magnitude (N*m)');
      ylim([0, 0.5]);
      title('Control Torque Magnitude','Color','k');
      whitePlot(gcf,gca);
end


function dydt = BVP_ode(~,y,Ic,tau_max)
    omega = y(1:3);
    lambda = y(4:6);
    v = Ic \ lambda;

    % Optimal Control Law
    tau_star = -v;
    if norm(tau_star) > tau_max
        tau_star = tau_max * (tau_star / norm(tau_star));
    end

    % State dynamics
    omega_dot = Ic \ (tau_star - cross(omega, Ic * omega));

      % Costate dynamics
      term1 = cross(Ic*omega, v);
      term2 = Ic * cross(omega, v);

      lambda_dot = term1 - term2;

      dydt = [omega_dot; lambda_dot];
end

function res = BVP_bc(ya,yb,omega0)
      omegaf = [0; 0; 0]; % Desired final angular velocity
      res = [ya(1:3) - omega0; % Initial condition on omega
             yb(1:3) - omegaf]; % Final condition on omega
end

function y0 = guess(omega0)
    % Initial guess for the solution
    y0 = zeros(6,1);
    y0(1:3) = omega0;
    y0(4:6) = zeros(3,1); % Initial guess for costates
end